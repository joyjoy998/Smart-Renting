import sha256 from 'crypto-js/sha256';

export async function registerUser(email, password) {
  try {
    
    const hashedPassword = sha256(password).toString();

    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: hashedPassword }),
    });

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Registration failed:', error);
    return { message: 'Error registering user' };
  }
}
