import { Signup } from "@clerk/nextjs";

const Signup = ( ) => (
 <SignUp path="/sign-up" routing="path" signInUrl="/sign-in" />
);

export default SignUpPage;





