import { clerkClient } from "@clerk/nextjs/server";

export default async function handler(req, res) {
 
  if (req.method !== 'POST') {
    return res.status(405).json({ 
      message: 'Method not allowed' 
    });
  }

  try {
  
    const authResult = await clerkClient.authenticateRequest(req, {
      authorizedParties: ['http://localhost:3000']
    });

   
    const userId = authResult.userId;
    const user = userId ? await clerkClient.users.getUser(userId) : null;

   
    return res.status(200).json({
      message: "Authenticated request!",
      user: user ? {
        id: user.id,
        email: user.emailAddresses[0]?.emailAddress,
        name: `${user.firstName} ${user.lastName}`
      } : null
    });

  } catch (error) {
   
    console.error('Authentication error:', error);
    
    return res.status(401).json({
      message: "Unauthorized request!",
      error: {
        type: error.name,
        message: error.message,
     
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      }
    });
  }
}